return {
  meta = {
    url = "https://github.com/ruby-formatter/rufo",
    description = "Rufo is an opinionated ruby formatter.",
  },
  command = "rufo",
  exit_codes = { 0, 3 },
}
