---@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://github.com/nix-community/nixpkgs-fmt",
    description = "nixpkgs-fmt is a Nix code formatter for nixpkgs.",
  },
  command = "nixpkgs-fmt",
}
