--@type conform.FileFormatterConfig
return {
  meta = {
    url = "https://git.sr.ht/~technomancy/fnlfmt",
    description = "A formatter for Fennel code.",
  },
  command = "fnlfmt",
  args = { "-" },
}
