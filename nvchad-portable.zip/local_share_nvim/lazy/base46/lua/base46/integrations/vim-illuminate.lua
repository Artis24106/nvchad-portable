return {
  IlluminatedWordText = { bold = true, reverse = true },
  IlluminatedWordRead = { bold = true, reverse = true },
  IlluminatedWordWrite = { bold = true, reverse = true },
}
